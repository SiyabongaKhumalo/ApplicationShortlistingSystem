package com.applicatiosShortlistingApp.applicationsShortlistingProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TeamCApplicationsSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
