package com.applicatiosShortlistingApp.applicationsShortlistingProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamCApplicationsSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TeamCApplicationsSystemApplication.class, args);
	}

}
